import threading
from time import sleep

from serial_listener import SerialListener
import datetime

class FlagHandler:
    def __init__(self, port, baudrate=9600, filename=None, verbose=False, mode=None):
        self.verbose = verbose
        if filename is not None:
            self.file = open(filename, 'w')
            self.filename = filename
        else:
            self.file = None
        self.serial_listener = SerialListener(port, baudrate, verbose)
        self.serial_listener.add_keyword('trgr0')
        self.quick = False
        self.normal = False
        self.safe = False
        self.write = False
        self.signal_thread = threading.Thread(target=self._send_signal)
        match mode:
            case None:
                self.serial_listener.bind_func_to_keyword('trgr0', self.add_and_write_timestamp)
                self.normal = True
            case 'safe':
                self.serial_listener.bind_func_to_keyword('trgr0', self.safe_add_and_write_timestamp)
                self.safe = True
                self.file.close() # Can cause unclosed file errors if not addressed
                if self.verbose: print("SAFE mode activated")
            case 'quick':
                self.serial_listener.bind_func_to_keyword('trgr0', self.add_timestamp())
                self.quick = True
                if self.verbose: print("QUICK mode activated")
        self.timestamps = []
        if self.verbose: print('flag handler initialized')

    def run(self):
        self.serial_listener.start()
        self.signal_thread.start()
        if self.verbose: print('Flag handler started')

    def stop(self):
        self.serial_listener.stop()
        self.signal_thread.join()
        if self.verbose: print('Flag handler stopped')
        if self.quick: self.write_timestamps()
        if self.normal or self.quick: self.file.close()

    def add_timestamp(self):
        now = datetime.datetime.now()
        self.timestamps.append(now)
        if self.write: self.write = False
        else: self.write = True
        if self.verbose: print(f'Timestamp {now} added; writing {self.write}')

    def write_timestamps(self):
        for timestamp in self.timestamps:
            self.write_timestamp(timestamp)

    def write_timestamp(self, timestamp):
        if timestamp not in self.timestamps:
            if self.verbose: print(f'timestamp {timestamp} not in timestamps {self.timestamps}')
        elif self.file is not None:
            self.file.write(str(timestamp) + '\n')
            if self.verbose: print(f'timestamp {timestamp} written')
        else:
            if self.verbose: print('no file given!')

    def add_and_write_timestamp(self):
        self.add_timestamp()
        self.write_timestamp(self.timestamps[-1])

    def safe_write_timestamp(self, timestamp):
        self.file = open(self.filename, 'a')
        self.write_timestamp(timestamp)
        self.file.close()

    def safe_add_and_write_timestamp(self):
        self.add_timestamp()
        self.safe_write_timestamp(self.timestamps[-1])

    def _send_signal(self):
        while True:
            if self.write: self.serial_listener.ser.write('y'.encode())
            else: self.serial_listener.ser.write('n'.encode())
            sleep(0.75)
