import serial
import threading

class SerialListener:
    def __init__(self, port, baudrate=9600, verbose=False):
        self.ser = serial.Serial(port, baudrate)
        self.verbose = verbose
        self.keywords = []
        self.funcs = {}
        self.running = False
        self.listening_thread = threading.Thread(target=self._start)
        if self.verbose: print('Serial listener initialized')

    def set_port(self, port, baudrate=9600):
        if not self.running:
            self.ser = serial.Serial(port, baudrate)
            if self.verbose: print(f'Serial listener set to {port} at {baudrate}')
        else:
            if self.verbose: print('Serial listener is running!')

    def add_keyword(self, keyword):
        self.keywords.append(keyword)
        if self.verbose: print(f'Keyword {keyword} added')

    def remove_keyword(self, keyword):
        self.keywords.remove(keyword)
        if self.verbose: print(f'Keyword {keyword} removed')

    def bind_func_to_keyword(self, keyword, func):
        if keyword not in self.keywords:
            if self.verbose: print(f'Keyword {keyword} not found, skipping...')
        else:
            self.funcs[keyword] = func
            if self.verbose: print(f'Function {func} bound to keyword {keyword}')

    def start(self):
        if self.running:
            if self.verbose: print('Serial listener already running, skipping...')
        else:
            self.running = True
            self.listening_thread.start()
            if self.verbose: print('Serial listener started')

    def stop(self):
        if not self.running:
            if self.verbose: print('Serial listener already stopped, skipping...')
        else:
            self.running = False
            self.listening_thread.join()
            if self.verbose: print('Serial listener stopped')

    def _start(self):
        while self.running:
            data = self.ser.readline().decode('utf-8').strip()
            for keyword in self.keywords:
                if keyword in data:
                    self.funcs[keyword]()
