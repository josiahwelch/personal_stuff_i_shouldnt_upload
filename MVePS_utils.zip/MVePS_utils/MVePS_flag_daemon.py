from flag_handler import FlagHandler
from datetime import datetime

def __main__():
    port = 'COM7'
    baudrate = 9600
    now = datetime.now()
    filename = now.strftime('data\\%Y-%m-%d-%H-%M-%S.mfl')
    flag_handler = FlagHandler(port, baudrate, filename, verbose=True, mode='safe')
    flag_handler.run()
    wait = input("")
    flag_handler.stop()

if __name__ == "__main__":
    __main__()
